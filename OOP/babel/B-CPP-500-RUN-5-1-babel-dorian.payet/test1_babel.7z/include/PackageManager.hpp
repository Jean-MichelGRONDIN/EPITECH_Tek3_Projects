/*
** EPITECH PROJECT, 2020
** Package
** File description:
** Manager
*/

#ifndef __packagemanager__
#define __packagemanager__

class PackageManager {
    public:
        PackageManager();
        ~PackageManager();
        void analyse_packet();
        
};

#endif /* !__packagemanager__ */
