/*
** EPITECH PROJECT, 2020
** package
** File description:
** manager
*/

#include "PackageManager.hpp"

PackageManager::PackageManager()
{
}

PackageManager::~PackageManager()
{
}
