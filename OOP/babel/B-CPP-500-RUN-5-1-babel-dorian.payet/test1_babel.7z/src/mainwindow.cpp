﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ClientCommunication.hpp"
#include <iostream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QObject::connect(ui->pushButton, SIGNAL(clicked(bool)), this, SLOT(newConnectionClient(bool)));

    // Server-client connection
    // QObject::connect(this->_socket.getSocket(), SIGNAL(readyRead()), this, SLOT(newPacket()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::newPacket()
{
    // Server 
    // QNetworkDatagram packet;
    // QByteArray bArr;

    // packet = _socket.readDatagram();
    // bArr = packet.data();
    // if (bArr[0] == Datagram::PackageType::CHAT)

}

void MainWindow::newConnectionClient(bool clicked)
{
    QFrame *frame = new QFrame(this);
    QVBoxLayout *layout = new QVBoxLayout();

    std::cout << "NEW CONNECTION" << std::endl;
    frame->setMinimumWidth(this->ui->tabWidget->width());
    frame->setMinimumHeight(this->ui->tabWidget->height());

    // layout->addWidget(new chattab());
    frame->setLayout(layout);

    this->ui->tabWidget->addTab(frame, tr("Chat"));
}
